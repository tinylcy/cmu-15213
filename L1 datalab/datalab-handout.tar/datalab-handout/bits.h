//1
int bitOr(int, int);
int test_bitOr(int, int);
int specialBits();
int test_specialBits();
//2
int isZero(int);
int test_isZero(int);
int anyEvenBit();
int test_anyEvenBit();
int negate(int);
int test_negate(int);
int leastBitPos(int);
int test_leastBitPos(int);
//3
int rotateLeft(int, int);
int test_rotateLeft(int, int);
int divpwr2(int, int);
int test_divpwr2(int, int);
int isLess(int, int);
int test_isLess(int, int);
//4
int isPower2(int);
int test_isPower2(int);
int bitReverse(int);
int test_bitReverse(int);
//float
unsigned float_abs(unsigned);
unsigned test_float_abs(unsigned);
unsigned float_i2f(int);
unsigned test_float_i2f(int);
unsigned float_times64(unsigned);
unsigned test_float_times64(unsigned);
